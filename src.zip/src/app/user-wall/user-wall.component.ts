import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { HttpClient, HttpErrorResponse, HttpParams} from  '@angular/common/http';
import { UserService } from '../services/user.service';
import { Observable } from 'rxjs';



@Component({
  selector: 'app-user-wall',
  templateUrl: './user-wall.component.html',
  styleUrls: ['./user-wall.component.css']
})
export class UserWallComponent implements OnInit {
  user:User
  constructor(private http:HttpClient,private userServices:UserService) { }

  ngOnInit() {
    this.userServices.fetchUser().subscribe((user:User)=>{
      this.user = user;
    })
    }            
  }
  
  
  

  // OnChange(response:Response){
  //   let body = response.json()
  //   if(body){
  //     return body
  //   }
  //   else{
  //     return{}
  //   }
  // }
